﻿using Microsoft.AspNetCore.Mvc.TagHelpers;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Projeto.Models;
using System.Collections.Generic;

namespace StudentHub.Models
{
    public class Materia
    {
        string conexao = "Server=ESN509VMYSQL;Database=studenthub;User id=aluno;Password=Senai1234";

        private string nome;
        [JsonProperty(PropertyName = "atividades")]
        public string Atividades { get; set; }

        public Materia(string nome, string atividades)
        {
            this.nome = nome;
            this.Atividades = atividades;
        }

        public void EnviarDados(List<Materia> materias, int serie)
        {
            MySqlConnection con = new MySqlConnection(conexao);
            con.Open();

            List<Atividade> atv = JsonConvert.DeserializeObject<List<Atividade>>(Atividades);

            string materiasJson = JsonConvert.SerializeObject(materias);


            MySqlCommand cmd = new MySqlCommand("UPDATE aluno SET atividades = @questao WHERE Numero = @serie", con);
            cmd.Parameters.AddWithValue("@serie", serie);
            cmd.Parameters.AddWithValue("@questao", materiasJson);
            cmd.ExecuteNonQuery();

            con.Close();
        }

        public List<Materia> BuscarDados()
        {
            List<Materia> materias = new List<Materia>();
            string conexao = "Server=localhost; Database=studenthub; User id=root; Password=";
            MySqlConnection con = new MySqlConnection(conexao);
            con.Open();

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM aluno", con);

            MySqlDataReader leitor = cmd.ExecuteReader();
            while (leitor.Read())
            {
                if (leitor["atividades"] != DBNull.Value)
                {
                    // Acessa a propriedade 'atividades' de cada objeto dentro do array JSON
                    JArray jsonArray = JArray.Parse(leitor["atividades"].ToString());
                    foreach (JObject jsonObj in jsonArray)
                    {
                        List<string> questoes = new List<string>();
                        List<string> respostas = new List<string>();

                        // Certifique-se de que o JSON contém as propriedades esperadas
                        if (jsonObj.TryGetValue("Questão", out JToken questaoToken) && jsonObj.TryGetValue("Resposta", out JToken respostaToken))
                        {
                            questoes.Add(questaoToken.ToString());
                            respostas.Add(respostaToken.ToString());
                        }

                        Atividade atv = new Atividade(questoes, respostas);
                        List<Atividade> atvList = new List<Atividade> { atv };

                        foreach (var ativ in atvList)
                        {
                            Materia materia = new Materia("portugues", JsonConvert.SerializeObject(ativ.Questoes));
                            materias.Add(materia);
                        }
                    }
                }
            }

            con.Close();
            return materias;
        }
    }
}
