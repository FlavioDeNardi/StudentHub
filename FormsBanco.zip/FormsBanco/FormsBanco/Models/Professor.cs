﻿using FormsBanco.Models;
using MySql.Data.MySqlClient;

namespace Projeto.Models
{
    public class Professor : User
    {
        static string conexao = "Server=ESN509VMYSQL;Database=studenthub;User id=aluno;Password=Senai1234";
        string cpfProf, nomeProf, senhaProf, disciplina;

        public Professor(string cpfProf, string nomeProf, string senhaProf, string disciplina) :base(cpfProf, senhaProf)
        {
            this.cpfProf = cpfProf;
            this.nomeProf = nomeProf;
            this.senhaProf = senhaProf;
            this.disciplina = disciplina;
        }

        public string CpfProf { get => cpfProf; set => cpfProf = value; }
        public string NomeProf { get => nomeProf; set => nomeProf = value; }
        public string SenhaProf { get => senhaProf; set => senhaProf = value; }
        public string Disciplina { get => disciplina; set => disciplina = value; }

        public string Inserir()
        {
            //Adicionar no BD
            MySqlConnection con = new MySqlConnection(conexao);
            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand(
                    "INSERT INTO professor VALUES(@cpf, @nome, @senha, @disciplina, @salas)", con);
                qry.Parameters.AddWithValue("@cpf", cpfProf);
                qry.Parameters.AddWithValue("@nome", nomeProf);
                qry.Parameters.AddWithValue("@senha", senhaProf);
                qry.Parameters.AddWithValue("@disciplina", disciplina);
                qry.Parameters.AddWithValue("@salas", null);
                qry.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                return "Erro: " + ex.Message;
            }
            return "Inserido com sucesso!";
        }
        public static List<Professor> BuscarTodos()
        {
            MySqlConnection con = new MySqlConnection(conexao);
            List<Professor> professores = new List<Professor>();

            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand("SELECT * FROM professor", con);
                MySqlDataReader reader = qry.ExecuteReader();

                while (reader.Read())
                {
                    Professor professor = new Professor(
                        reader["cpf"].ToString(),
                        reader["nome"].ToString(),
                        reader["senha"].ToString(),
                        reader["disciplina"].ToString()
                    );
                    professores.Add(professor);
                }

                reader.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                return new List<Professor>(); // Retorna uma lista vazia em caso de erro
            }

            return professores;
        }
    }
}
