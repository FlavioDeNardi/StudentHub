﻿using FormsBanco.Models;
using MySql.Data.MySqlClient;

namespace Projeto.Models
{
    public class Diretor :User
    {
        static string conexao = "Server=ESN509VMYSQL;Database=studenthub;User id=aluno;Password=Senai1234";
        private string cpfDiretor, nomeDiretor, senhaDiretor;

        public Diretor(string cpfDiretor, string nomeDiretor, string senhaDiretor) : base(cpfDiretor, senhaDiretor)
        {
            this.cpfDiretor = cpfDiretor;
            this.nomeDiretor = nomeDiretor;
            this.senhaDiretor = senhaDiretor;
        }
        public string CpfDiretor { get => cpfDiretor; set => cpfDiretor = value; }
        public string NomeDiretor { get => nomeDiretor; set => nomeDiretor = value; }
        public string SenhaDiretor { get => senhaDiretor; set => senhaDiretor = value; }

        public string Inserir()
        {
            //Adicionar no BD
            MySqlConnection con = new MySqlConnection(conexao);
            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand(
                    "INSERT INTO diretor VALUES(@cpf, @nome, @senha)", con);
                qry.Parameters.AddWithValue("@cpf", cpfDiretor);
                qry.Parameters.AddWithValue("@nome", nomeDiretor);
                qry.Parameters.AddWithValue("@senha", senhaDiretor);
                qry.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                return "Erro: " + ex.Message;
            }
            return "Inserido com sucesso!";
        }
        public static List<Diretor> BuscarTodos()
        {
            MySqlConnection con = new MySqlConnection(conexao);
            List<Diretor> diretores = new List<Diretor>();

            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand("SELECT * FROM diretor", con);
                MySqlDataReader reader = qry.ExecuteReader();

                while (reader.Read())
                {
                    Diretor diretor = new Diretor(
                        reader["cpf"].ToString(),
                        reader["nome"].ToString(),
                        reader["senha"].ToString()
                    );
                    diretores.Add(diretor);
                }

                reader.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                return new List<Diretor>(); // Retorna uma lista vazia em caso de erro
            }

            return diretores;
        }

    }
}
