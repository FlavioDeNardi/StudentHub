﻿using MySql.Data.MySqlClient;
using Projeto.Models;

namespace FormsBanco.Models
{
    public class Sala
    {
        private int num;
        private string cpfDiretor;
        static string conexao = "Server=ESN509VMYSQL;Database=studenthub;User id=aluno;Password=Senai1234";

        public Sala(int num, string cpfDiretor)
        {
            this.num = num;
            this.cpfDiretor = cpfDiretor;
        }

        public int Num { get => num; set => num = value; }
        public string CpfDiretor { get => cpfDiretor; set => cpfDiretor = value; }
        
        public string Inserir()
        {
            MySqlConnection con = new MySqlConnection(conexao);
            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand("INSERT INTO sala VALUES(@Numero, @cpfDiretor, null)", con);
                qry.Parameters.AddWithValue("@Numero", Num);
                qry.Parameters.AddWithValue("@CPFDiretor", CpfDiretor);
                qry.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                return "Erro:" + ex.Message;
            }
            return "Inserido com sucesso";

        }
        public static List<Sala> buscarSalas()
        {
            MySqlConnection con = new MySqlConnection(conexao);
            List<Sala> salas = new List<Sala>();

            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand("SELECT * FROM sala", con);
                MySqlDataReader reader = qry.ExecuteReader();

                while (reader.Read())
                {
                    Sala sala = new Sala(
                        Convert.ToInt32(reader["Numero"].ToString()),
                        reader["CPFDiretor"].ToString()
                        ) ;
                    salas.Add(sala);
                }
                
            }
            catch (Exception ex)
            {
                return new List<Sala>(); // Retorna uma lista vazia em caso de erro
            }

            return salas;
        }
    }
}
