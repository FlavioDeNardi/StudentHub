﻿namespace FormsBanco.Models
{
    public class User
    {
        public string cpf;
        public string senha;

        public User(string cpf, string senha)
        {
            this.cpf = cpf;
            this.senha = senha;
        }

        public string Senha { get => senha; set => senha = value; }
        public string Cpf { get => cpf; set => cpf = value; }
    }
}
