﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using FormsBanco.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto.Models
{
    internal class Aluno : User
    {
        static string conexao = "Server=ESN509VMYSQL;Database=studenthub;User id=aluno;Password=Senai1234";
        private string nome, serie, matricula, dataNascimento, numero;
        [JsonProperty(PropertyName = "atividades")]
        private string atividades;

        public Aluno(string cpf, string senha,string nome, string serie, string matricula, string dataNascimento, string numero, string atividades) : base (cpf, senha)
        {
        
            this.nome = nome;
            this.serie = serie;
            this.matricula = matricula;
            this.dataNascimento = dataNascimento;
            this.numero = numero;
            this.atividades = atividades;
        }

        public string Nome { get => nome; set => nome = value; }
        public string Serie { get => serie; set => serie = value; }
        public string Matricula { get => matricula; set => matricula = value; }
        public string DataNascimento { get => dataNascimento; set => dataNascimento = value; }
        public string Numero { get => numero; set => numero = value; }
        public string Atividades { get => atividades; set => atividades = value; }

        public string mostrar()
        {
            return Cpf +
                "\n" + Nome +
                "\n" + Serie +
                "\n" + Matricula +
                "\n" + DataNascimento +
                "\n" + Senha +
                "\n" + Numero +
                "\n" + Atividades;
        }
        public string Inserir()
        {
            //Adicionar no BD
            MySqlConnection con = new MySqlConnection(conexao);
            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand(
                "INSERT INTO aluno VALUES(@CPF, @Nome, @Serie, @Matricula, @Data_Nascimento, @Senha, @Numero, @Atividades)", con);
                qry.Parameters.AddWithValue("@CPF", cpf);
                qry.Parameters.AddWithValue("@Nome", senha);
                qry.Parameters.AddWithValue("@Serie", nome);
                qry.Parameters.AddWithValue("@Matricula", serie);
                qry.Parameters.AddWithValue("@Data_Nascimento", matricula);
                qry.Parameters.AddWithValue("@Senha", dataNascimento);
                qry.Parameters.AddWithValue("@Numero", numero);
                qry.Parameters.AddWithValue("@Atividades", null);
                qry.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                return "Erro: " + ex.Message;
            }
            return "Inserido com sucesso!";
        }
        public static List<Aluno> BuscarTodos()
        {
            MySqlConnection con = new MySqlConnection(conexao);
            List<Aluno> alunos = new List<Aluno>();

            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand("SELECT * FROM aluno", con);
                MySqlDataReader reader = qry.ExecuteReader();

                while (reader.Read())
                {
                    Aluno aluno = new Aluno(
                        reader["CPF"].ToString(),
                        reader["Senha"].ToString(),
                        reader["Nome"].ToString(),
                        reader["Serie"].ToString(),
                        reader["Matricula"].ToString(),
                        ((DateTime)reader["Data_Nascimento"]).ToString("dd-MM-yyyy"),
                        reader["Numero"].ToString(),
                        reader["Atividades"].ToString()
                    );
                    alunos.Add(aluno);
                }

                reader.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                return new List<Aluno>();
            }

            return alunos;
        }

    }
}
