﻿namespace StudentHub.Models
{
    public class Atividade
    {
        private List<String> questoes;
        private List<String> respostas;

        public Atividade(List<string> questoes, List<string> respostas)
        {
            this.questoes = questoes;
            this.respostas = respostas;
        }

        public List<string> Questoes { get => questoes; set => questoes = value; }
        public List<string> Respostas { get => respostas; set => respostas = value; }

    }
}
