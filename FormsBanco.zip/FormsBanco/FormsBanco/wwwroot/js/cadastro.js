﻿ function mostrarCampos() {
            const tipoConta = document.getElementById('tipoConta');
            const cadastroForm = document.getElementById('cadastroForm');

            const selectedOption = tipoConta.options[tipoConta.selectedIndex];
            const actionUrl = selectedOption.getAttribute('data-action');

            const baseUrl = window.location.origin;
            cadastroForm.setAttribute('action', `${baseUrl}/${actionUrl}`);

            document.getElementById('camposAluno').classList.add('hidden');
            document.getElementById('camposProfessor').classList.add('hidden');
            document.getElementById('camposDiretor').classList.add('hidden');

            if (tipoConta.value === 'aluno') {
                document.getElementById('camposAluno').classList.remove('hidden');
            } else if (tipoConta.value === 'professor') {
                document.getElementById('camposProfessor').classList.remove('hidden');
            } else if (tipoConta.value === 'diretor') {
                document.getElementById('camposDiretor').classList.remove('hidden');
            }
        }