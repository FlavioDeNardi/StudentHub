

// Get references to the elements
const addItemBtns = document.querySelectorAll('#addItemBtn');

// Add event listener for adding items to each checklist
addItemBtns.forEach(btn => {
    btn.addEventListener('click', addItem);
});

// Function to add item
function addItem(event) {
    const checklist = event.target.parentNode; // Obtém o elemento pai do botão clicado
    const pergunta = prompt("Digite a atividade:");
    const resposta = prompt("Resposta da Atividade:");


    if (pergunta && resposta) {
        enviarDadosParaBackend(pergunta, resposta);

        const newItem = document.createElement('div');
        newItem.classList.add('cardAtividade');
        newItem.innerHTML = `
            <p>${pergunta}</p>
            <p>${resposta}</p>
        `;
        checklist.appendChild(newItem);
        return newItem;
    }

}
// Add event listener for removing items
const removeBtn = newItem.querySelector('.removeBtn');
removeBtn.addEventListener('click', () => {
    checklist.removeChild(newItem);
});

// Add event listener for adding items to each checklist
addItemBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        // Mostra o menu lateral
        addItemMenu.classList.add('active');
        // Armazena o itemGrid ativo
        activeGrid = btn.parentNode.querySelector('.containerCards');
    });
});

// Event listener para enviar item
sendItemBtn.addEventListener('click', () => {
    const pergunta = questionInput.value;
    const resposta = answerInput.value;

    if (activeGrid) {
        // Adiciona o novo item à itemGrid ativa
        const newItem = document.createElement('div');
        newItem.classList.add('itemGrid');
        newItem.innerHTML = `
             <p>${pergunta}</p>
            <p>${resposta}</p>
        `;
        activeGrid.appendChild(newItem);
    }

    // Limpa os campos de entrada
    questionInput.value = '';
    answerInput.value = '';

    // Esconde o menu lateral
    addItemMenu.classList.remove('active');
});
function enviarDadosParaBackend(question, answer) {
    console.log("Enviando dados para o backend:", question, answer);
    // Adiciona os dados como parâmetros de consulta na URL
    const url = `/Checklist/AdicionarItem?pergunta=${encodeURIComponent(question)}&resposta=${encodeURIComponent(answer)}`;

    fetch(url, {
        method: 'POST'
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao enviar os dados para o backend');
            }
            return response.text();
        })
        .then(data => {
            console.log("Resposta do backend:", data);
        })
        .catch(error => {
            console.error('Erro:', error);
        });
}
