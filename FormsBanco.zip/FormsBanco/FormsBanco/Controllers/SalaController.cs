﻿using FormsBanco.Models;
using Microsoft.AspNetCore.Mvc;

namespace StudentHub.Controllers
{
    public class SalaController : Controller
    {
        public IActionResult Index()
        {
            List<Sala> salas = Sala.buscarSalas();
            ViewBag.Salas = salas;

            return View();
        }
        
        
        public IActionResult InserirSala(string user)
        {
            ViewBag.User = user;
            return View();
        }
        [HttpPost]
        public IActionResult InserirSala(int numSala, string cpfDiretor, string user)
        {
            Sala sala = new Sala(numSala, cpfDiretor);
            sala.Inserir();
            TempData["User"] = user;
            return RedirectToAction("Index", "Sala");

        }
    }
}
