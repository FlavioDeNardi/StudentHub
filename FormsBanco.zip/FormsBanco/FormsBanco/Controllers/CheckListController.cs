﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StudentHub.Models;

namespace FormsBanco.Controllers
{
    public class CheckListController : Controller
    {
        [HttpPost]
        public ActionResult AdicionarItem(List<string> pergunta, List<string> resposta)
        {
            List<Atividade> atividades = new List<Atividade>();

            Atividade atividade = new Atividade(pergunta, resposta);

            atividades.Add(atividade);

            Materia materia = new Materia("Portugay", JsonConvert.SerializeObject(atividades));

            List<Materia> materias = new List<Materia>();

            materias.Add(materia);

            materia.EnviarDados(materias, 1);

            return RedirectToAction("Atividade", "Index");
        }


    }
}
