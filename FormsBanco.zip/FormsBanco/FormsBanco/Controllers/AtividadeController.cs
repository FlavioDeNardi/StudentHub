﻿using Microsoft.AspNetCore.Mvc;
using StudentHub.Models;

namespace StudentHub.Controllers
{
    public class AtividadeController : Controller
    {
        public IActionResult Index(int num)
        {
            ViewBag.NumSala = num;
            List<Materia> materias = new List<Materia>();
            Materia materia = new Materia(null, null);
            materias = materia.BuscarDados();
            return View();
        }
    }
}
