﻿using Microsoft.AspNetCore.Mvc;
using Projeto.Models;

namespace Projeto.Controllers
{
    public class DiretorController : Controller
    {
        public IActionResult Inserir()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Inserir(string cpfDiretor, string nomeDiretor, string senhaDiretor)
        {
            Diretor diretor = new Diretor(cpfDiretor,nomeDiretor,senhaDiretor);
            TempData["MsgCadastro"] = diretor.Inserir();
            return RedirectToAction("Index", "Home");
        }
    }
}
