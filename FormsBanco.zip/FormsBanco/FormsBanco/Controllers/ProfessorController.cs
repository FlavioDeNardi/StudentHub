﻿using Microsoft.AspNetCore.Mvc;
using Projeto.Models;

namespace Projeto.Controllers
{
    public class ProfessorController : Controller
    {
        public IActionResult Inserir()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Inserir(string cpfProfessor, string nomeProfessor, string senhaProfessor, string disciplina)
        {
            Professor prof = new Professor(cpfProfessor, nomeProfessor, senhaProfessor, disciplina);
            TempData["MsgCadastro"] = prof.Inserir();
            return RedirectToAction("Index", "Home");

        }
    }
}
