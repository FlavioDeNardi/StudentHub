using FormsBanco.Models;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Pqc.Crypto.Cmce;
using Projeto.Models;
using System.Diagnostics;

namespace StudentHub.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            if (TempData["MsgCadastro"] != null)
            {
                ViewBag.MsgCadastro = TempData["MsgCadastro"].ToString();
            }
            return View();
        }
        [HttpPost]
        public IActionResult Index(string cpfUser, string senhaUser)
        {
            string usuarioLogado = null;
            User user = null;
            Boolean achouUser = false;
            List<Aluno> alunos = Aluno.BuscarTodos();
            List<Professor> professores = Professor.BuscarTodos();
            List<Diretor> diretores = Diretor.BuscarTodos();
            foreach (Aluno aluno in alunos)
            {
                if(aluno.Cpf.Equals(cpfUser) && aluno.Senha.Equals(senhaUser))
                {
                    usuarioLogado = aluno.GetType().Name;
                    achouUser = true;
                    user = aluno;
                    
                } 
            }
            foreach (Professor prof in professores)
            {
                if(prof.CpfProf.Equals(cpfUser) && prof.SenhaProf.Equals(senhaUser))
                {
                    usuarioLogado = prof.GetType().Name;
                    achouUser = true;
                    user = prof;
                }
            }
            foreach (Diretor diretor in diretores)
            {
                if(diretor.CpfDiretor.Equals(cpfUser) && diretor.SenhaDiretor.Equals(senhaUser))
                {
                    usuarioLogado = diretor.GetType().Name;
                    achouUser = true;
                    user = diretor;
                  
                }
            }
            if (achouUser)
            {
                TempData["User"] = user.Cpf;
                TempData["TipoConta"] = usuarioLogado;
                return RedirectToAction("Index", "Sala");
            }else
            {
                ViewBag.Msg = "Usu�rio ou Senha Incorretos!!";
                return View();
            }
            
            

        }

    }
}
