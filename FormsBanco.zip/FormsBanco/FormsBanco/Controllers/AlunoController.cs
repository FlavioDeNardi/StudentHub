﻿using Google.Cloud.Translation.V2;
using Microsoft.AspNetCore.Mvc;
using Projeto.Models;

namespace Projeto.Controllers
{
    public class AlunoController : Controller
    {
        public IActionResult Inserir()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Inserir(string cpfAluno, string nomeAluno, string serie, string matricula, string dataNascimento, string senhaAluno)
        {

                Aluno aluno = new Aluno(cpfAluno, nomeAluno, serie, matricula, dataNascimento, senhaAluno, null, null);
           
            
            TempData["MsgCadastro"] = aluno.Inserir();
            
            return RedirectToAction("Index", "Home");
        }
    }
}
